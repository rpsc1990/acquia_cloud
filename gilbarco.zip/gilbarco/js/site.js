var navbarTopPos = 0;
var overlappingHPNav = 1;
/*var nonMenuWidth = 200;
var menuWidth = 250;
var menuColumnWidth = 230;*/

(function ($, Drupal) {

  // Mobile menu toggle
  $('.navbar-toggle, .slide-menu-close').on('click', function() {
    $('body').toggleClass('slide-menu-on');
  });

  // Header search block
  // $('#search-region-wrapper form button.form-submit').html('<span class="icon glyphicon glyphicon-search" aria-hidden="true"></span>');

  $('.header-nav-icons i.search-btn').on('click', function() {
    if ($('#search-region-wrapper').hasClass('search-visible')) {
      $('#search-region-wrapper').removeClass('search-visible');
      $('.header-nav-icons i.search-btn').removeClass('fa-remove');
      $('.header-nav-icons i.search-btn').addClass('fa-search');
    }
    else {
      $('#search-region-wrapper').addClass('search-visible');
      $('.header-nav-icons i.search-btn').removeClass('fa-search');
      $('.header-nav-icons i.search-btn').addClass('fa-remove');
      $('#search-region-wrapper .search-block-form form input.form-search').trigger('focus');
    }    
  });

  // Region selector
  $('.header-nav-icons i.regional-sites-btn').on('click', function() {
    if ($('#navbar-position-wrapper').hasClass('show-regions')) {
      $('#navbar-position-wrapper').removeClass('show-regions');
      $('#region-selector-wrapper').removeClass('enable-scroll');
    }
    else {
      $('#navbar-position-wrapper').addClass('show-regions');
      setTimeout(function() {
        $('#region-selector-wrapper').addClass('enable-scroll');
      }, 500);
    }
  });

  $(window).resize(function() {

    // Set height of mobile menu
    var navbarBottom = 0;
    var regionSelectorHeight = 0;
    if ($('#navbar-position-wrapper').length) {
      navbarBottom = ($('#navbar-position-wrapper').position().top + $('#navbar-position-wrapper').height());
    }
    if ($('#navbar-position-wrapper').hasClass('show-regions')) {
      regionSelectorHeight = 330;
    }
    var slideMenuHeight = $(window).height() + regionSelectorHeight - navbarBottom;
    $('#slide-menu').height(slideMenuHeight);

    if ($('body').width() < 975) {
      $('body').removeClass('lg-screen');
      $('body').addClass('md-screen');
    }
    else {
      $('body').removeClass('md-screen');
      $('body').addClass('lg-screen');
    }
      
    // Set fixed header
    var headerHeight = $('#navbar-position-wrapper').height() - regionSelectorHeight;
    if ($('#header-wrapper').hasClass('overlapping-nav')) {
      $('#header-wrapper').height(0);
    }
    else {
      $('#header-wrapper').height(headerHeight);
    }
  });
  $(window).trigger('resize'); //initialize

  // Add down arrows to mobile sub-menus
  // $('nav#main-navigation .region-navigation ul.menu > li.dropdown > a').append('&nbsp;<i class="fa fa-angle-down" aria-hidden="true"></i>');
  $('nav#main-navigation .region-navigation ul.menu > li.dropdown').append('<div class="arrow-down"></div>');

  //Mobile menu: submenu dropdowns hide/show
  $('#slide-menu ul.menu li.dropdown').prepend('<i class="fa fa-angle-down" aria-hidden="true"></i>');
  $('#slide-menu ul.menu li.dropdown i.fa').click(function() {
    var liParent = $(this).parent();
    if(liParent.hasClass('active-sub')) {          
      // liParent.children('ul.dropdown-menu').slideUp(400, 'swing');
      liParent.removeClass('active-sub');
    }
    else {
      liParent.parent().children('li.dropdown.active-sub').children('i').click();
      // liParent.children('ul.dropdown-menu').slideDown(400, 'swing');
      liParent.addClass('active-sub');
    }
  });

  // Sidebar navigation dropdowns
  $('.region-sidebar ul.sidebar-nav li.active-trail').addClass('active-sub');
  $('.region-sidebar ul.sidebar-nav li.dropdown i.fa').click(function() {
    var liParent = $(this).parent();
    if(liParent.hasClass('active-sub')) {
      liParent.children('ul').slideUp();
      liParent.removeClass('active-sub');
    }
    else {
      liParent.parent().children('li.dropdown.active-sub').children('span').click();
      liParent.children('ul').slideDown();
      liParent.addClass('active-sub');
    }
  });  
  $('.region-sidebar ul.sidebar-nav li.active-trail.active-sub > i.fa').trigger('click');

  // On homepage, header is floating
  // No need for below code as login is placed in page.html.twig to add overlapping-nav class
  /*if ($('body').hasClass('path-frontpage') && overlappingHPNav) {
    $('#header-wrapper').addClass('overlapping-nav');
  }*/

  // Window scroll pinding for floating elements
  $(window).bind('scroll', function () {

    // Opaque header
    if ($(window).scrollTop() > navbarTopPos) {
      $('#header-wrapper').addClass('opaque');
    } else {
      $('#header-wrapper').removeClass('opaque');
    }

    // Floating horizontal secondary nav
    if ($('.secondary-nav-sticky').length) {
      var headerHeight = $('#header-wrapper').offset().top + $('#header-wrapper').outerHeight(true);
      var secNavOffsetTop = $('#header-wrapper').offset().top + $('#header-wrapper').outerHeight(true) + $(window).scrollTop();
      if (secNavOffsetTop > $('.secondary-nav-sticky').offset().top) {
        var secNavHeight = $('.secondary-nav-sticky').height();
        $('.secondary-nav-sticky').height(secNavHeight);
        $('.secondary-nav-sticky').addClass('fixed');
        $('.secondary-nav-sticky ul').css('top', headerHeight);
      }
      else {
        headerHeight = 0;
        secNavOffsetTop = 0;
        $('.secondary-nav-sticky').height('auto');
        $('.secondary-nav-sticky').removeClass('fixed');
        $('.secondary-nav-sticky ul').css('top', headerHeight);
      }
    }
  });

  //Detect HTML 5 support and display appropriate message
  (function(doc) {
    var isHtml5Compatible = document.createElement('canvas').getContext != undefined;
    if (!isHtml5Compatible) {
      var ba = navigator.userAgent;
      if (ba.indexOf("MSIE")>0) {
        $('#compatiblity-content').removeClass('hide');
        $("#unsupported-browser-modal").modal();
      }
      else {
        $('#unsupported-browser-content').removeClass('hide');
        $("#unsupported-browser-modal").modal();
      }
      //Set height of backdrop screen, specifically required for IE < 8
      setTimeout(function() {$('div.modal-backdrop').height($(window).height() + 'px');}, 100);
    }

    var titleStyleHTML = '<div class="title-styling"><div class="gvr-color-strip"><div class="col-xs-4 gvr-red"></div><div class="col-xs-4 gvr-green"></div><div class="col-xs-4 gvr-blue"></div></div></div>';

    $('.gvr-block-title h2').append(titleStyleHTML);
  })(document);

  Drupal.behaviors.gilbarco = {
    attach: function (context, settings) {
      $(window).trigger('resize'); //initialize
      $('#header-wrapper').addClass('fixed');

      // Used for dropdown show/hide like distributor locator or EV incentive listing
      $(once('gvr-dd-select-list', $('#gvr-dd-select-list'))).change(function() {
        var new_active = $(this).val();
        if($('.details-wrapper.active').length) {
          $('.details-wrapper.active').slideUp(300, function() {
            $('.active').removeClass('active');
            $('#' + new_active).addClass('active');
            $('.details-wrapper.active').slideDown(500);
          });
        }
        else {
          $('#' + new_active).addClass('active');
          $('.details-wrapper.active').slideDown(500);
        }
      });
    }
  };

})(jQuery, Drupal);
