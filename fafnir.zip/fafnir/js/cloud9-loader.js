(function ($, Drupal) {
  Drupal.behaviors.fafnirCloud9 = {
    attach: function (context, settings) {
      $("#cloud9-carousel").css( 'visibility', 'hidden' ).Cloud9Carousel({
        buttonLeft: $("#cloud9-carousel-wrapper .left-nav"),
        buttonRight: $("#cloud9-carousel-wrapper .right-nav"),
        autoPlay: 1,
        autoPlayDelay: 5000,
        bringToFront: true,
        itemClass: 'col-md-6',
        yRadius: 50,
        farScale: 0.2,
        frontItemClass: 'front-slide',
        onLoaded: function( carousel ) {
          // Show carousel
          $("#cloud9-carousel").css( 'visibility', 'visible' );
        }
      });

      // On clicking the <a> tag in carousel slide, it triggers parent's slide transition event.
      // Disable this tranistion event like below.
      $("#cloud9-carousel a", context).click(function(e) {
        e.stopPropagation();
     });
    }
  }
})(jQuery, Drupal);