(function ($, Drupal) {

  /* Search toggle */
  /*$('.search-open-action')on('click', function() {
    if (!$('#search-region-wrapper').hasClass('search-open')) {
      $('#search-region-wrapper').addClass('search-open');
    }
  });
  $('.search-close-action')on('click', function() {
    if ($('#search-region-wrapper').hasClass('search-open')) {
      $('#search-region-wrapper').removeClass('search-open');
    }
  });*/

  // Mobile menu toggle
  $('.navbar-toggle').on('click', function() {
    $('#header-region-wrapper').toggleClass('slide-menu-on');
  });

  // Mobile menu item dropdown toggle
  mobile_menu_dd_toggle = function(e) {
    $(e).parent().toggleClass('dropdown-active');
  };

  // Sitemap: Add class to <li>'s with sub-menu
  $('.sitemap-item--menu-main > div > ul > li ul').each(function() {
    $(this).parent().addClass('has-sub-menu');
  });

  Drupal.behaviors.fafnir = {
    attach: function (context, settings) {
      $('.search-open-action', context).click(function () {
        if (!$('#search-region-wrapper').hasClass('search-open')) {
          $('#search-region-wrapper').addClass('search-open');
        }
      });
      $('.search-close-action', context).click(function () {
        if ($('#search-region-wrapper').hasClass('search-open')) {
          $('#search-region-wrapper').removeClass('search-open');
        }
      });

      $('.scroll-pu', context).click(function() {
        $.scrollTo('-=' + (jQuery(window).height() - 120) + 'px', 800)
      });

      $('.scroll-pd', context).click(function() {
        $.scrollTo('+=' + (jQuery(window).height() - 120) + 'px', 800)
      });

      $(once('rfq-button', $('.rfq-button'), context)).click(function() {
        $(this).parent().toggleClass('form-open');
      });

      // Open RFQ form if 'rfq-form' in URL
      var url = window.location.href;
      var arguments = url.split('#')[1];
      if (arguments == 'rfq-form') {
        $('.rfq-button', context).click();
      }

      // Downloads quick links
      var ql_fixed_view = '';
      if ($('.view-product-information').length) {
        ql_fixed_view = 'view-product-information';
      }
      else if($('.view-technical-documentation').length) {
        ql_fixed_view = 'view-technical-documentation';
      }
      else if($('.view-certificates-approvals').length) {
        ql_fixed_view = 'view-certificates-approvals';
      }
      if ($('.in-page-quick-links', context).length && $(window).outerWidth() > 991 && ql_fixed_view != '') {
        var header_bottom = $('#header-wrapper').offset().top - $(document, context).scrollTop() + $('#header-wrapper').outerHeight();
        var ql_top = $('.in-page-quick-links').offset().top;
        $('.in-page-quick-links').css('z-index', 1);
        $(document, context).on('scroll',{qlv: ql_fixed_view, hb: header_bottom, qlt: ql_top}, function(event) {
          var ql_fixed_view = event.data.qlv;
          var header_bottom = event.data.hb;
          var ql_top = event.data.qlt
          var threshold = $(document, context).scrollTop() + header_bottom;

          if (threshold > ql_top) {
            $('.' + ql_fixed_view).css('margin-top', $('.in-page-quick-links').outerHeight());
            $('.in-page-quick-links').css('position', 'fixed');
            $('.in-page-quick-links').css('top', header_bottom);
            $('.in-page-quick-links').addClass('fixed');
          }
          else {
            $('.' + ql_fixed_view).css('margin-top', 0);
            $('.in-page-quick-links').css('position', 'static');
            $('.in-page-quick-links').removeClass('fixed');
          }
        });
      }
    }
  };

})(jQuery, Drupal);
